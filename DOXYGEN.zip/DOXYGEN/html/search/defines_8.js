var searchData=
[
  ['temp_5fwindow_5fsize_0',['TEMP_WINDOW_SIZE',['../temperature_8h.html#ac411e77a9c1eeccba64434d161155810',1,'temperature.h']]],
  ['temperature_5fchl_1',['TEMPERATURE_CHL',['../main_8h.html#a3b6e64a12c09cce012091895a7bf0051',1,'main.h']]],
  ['trig_5fpin_2',['TRIG_PIN',['../main_8h.html#a8eab89acd7dcb0e77e7b00d1749022a6',1,'main.h']]]
];
