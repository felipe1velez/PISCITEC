var searchData=
[
  ['servo1_5fpin_0',['SERVO1_PIN',['../main_8h.html#acc407398818b8e8fe8a1e314f762db21',1,'main.h']]],
  ['servo_5fg_1',['servo_g',['../food_8c.html#aee736d391ecfef62623cbbb6d7273aa3',1,'food.c']]],
  ['servo_5fpwm_5finit_2',['servo_pwm_init',['../food_8c.html#af04ff1078dae8fb32829f3405a6f1259',1,'servo_pwm_init(uint8_t servo_gpio):&#160;food.c'],['../food_8h.html#a274545a3bf8210779fde1fbcd3e01d20',1,'servo_pwm_init(uint8_t gpio):&#160;food.c']]]
];
