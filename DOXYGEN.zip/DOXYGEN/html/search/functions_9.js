var searchData=
[
  ['servo_5fpwm_5finit_0',['servo_pwm_init',['../food_8c.html#af04ff1078dae8fb32829f3405a6f1259',1,'servo_pwm_init(uint8_t servo_gpio):&#160;food.c'],['../food_8h.html#a274545a3bf8210779fde1fbcd3e01d20',1,'servo_pwm_init(uint8_t gpio):&#160;food.c']]]
];
