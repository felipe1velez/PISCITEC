var searchData=
[
  ['read_5flights_0',['read_lights',['../lights_8c.html#a26a91c989ed5e5c7a8f8253cdc693cb4',1,'lights.c']]],
  ['read_5ftemperature_1',['read_temperature',['../temperature_8c.html#a869e6863ef75261ca8f4a78c616ea2b4',1,'read_temperature():&#160;temperature.c'],['../temperature_8h.html#a869e6863ef75261ca8f4a78c616ea2b4',1,'read_temperature():&#160;temperature.c']]]
];
