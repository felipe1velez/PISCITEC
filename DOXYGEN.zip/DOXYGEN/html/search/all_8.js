var searchData=
[
  ['main_0',['main',['../main_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.c']]],
  ['main_2ec_1',['main.c',['../main_8c.html',1,'']]],
  ['main_2eh_2',['main.h',['../main_8h.html',1,'']]],
  ['media_5fmovil_3',['media_movil',['../temperature_8c.html#a6634f5bff35f440121c23eb991ac11f5',1,'media_movil(float nuevo_valor):&#160;temperature.c'],['../temperature_8h.html#a6634f5bff35f440121c23eb991ac11f5',1,'media_movil(float nuevo_valor):&#160;temperature.c']]],
  ['media_5fmovil2_4',['media_movil2',['../lights_8c.html#a372d65281b6b80ad5df38ef300b97497',1,'media_movil2(float nuevo_valor):&#160;lights.c'],['../lights_8h.html#a372d65281b6b80ad5df38ef300b97497',1,'media_movil2(float nuevo_valor):&#160;lights.c']]],
  ['moving_5faverage_5',['moving_average',['../main_8c.html#a0186ce71e843aaf61baa9ebde2dbc770',1,'moving_average(float new_value):&#160;main.c'],['../main_8h.html#a0186ce71e843aaf61baa9ebde2dbc770',1,'moving_average(float new_value):&#160;main.c']]]
];
