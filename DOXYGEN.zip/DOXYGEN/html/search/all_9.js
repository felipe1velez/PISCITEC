var searchData=
[
  ['oled_0',['oled',['../main_8c.html#a03de839a9debec4f2265023b765444ad',1,'main.c']]],
  ['oled_5fupdate_5fdisplay_1',['oled_update_display',['../main_8c.html#a664c949699641b5596a722605035fb20',1,'main.c']]],
  ['open_5fms_2',['OPEN_MS',['../food_8h.html#a3328416c99fd3d5165a2febccabdd3bf',1,'food.h']]]
];
