var searchData=
[
  ['init_5fadc_0',['init_adc',['../temperature_8c.html#abddb114b739412e90007c205013a9105',1,'init_adc(uint8_t input_channel):&#160;temperature.c'],['../temperature_8h.html#abddb114b739412e90007c205013a9105',1,'init_adc(uint8_t input_channel):&#160;temperature.c']]],
  ['irq_5fcall_5fback_1',['irq_call_back',['../main_8c.html#a907f89562b499407007a097c4e45d489',1,'irq_call_back(uint gpio, uint32_t events):&#160;main.c'],['../main_8h.html#a907f89562b499407007a097c4e45d489',1,'irq_call_back(uint gpio, uint32_t events):&#160;main.c']]]
];
