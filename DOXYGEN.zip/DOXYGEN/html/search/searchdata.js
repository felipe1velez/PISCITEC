var indexSectionsWithContent =
{
  0: "abcefhilmoprstvw",
  1: "flmt",
  2: "acfilmoprst",
  3: "host",
  4: "bcefhlostvw"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables",
  4: "Macros"
};

