var searchData=
[
  ['food_2ec_0',['food.c',['../food_8c.html',1,'']]],
  ['food_2eh_1',['food.h',['../food_8h.html',1,'']]],
  ['food_5fclose_2',['FOOD_CLOSE',['../food_8h.html#ac53ad709629ec112e3376934143921eb',1,'food.h']]],
  ['food_5fcontrol_3',['food_control',['../food_8c.html#a6469255fc0e469bc665c30ae46210133',1,'food_control(uint8_t servo_gpio, uint8_t food_case, float top):&#160;food.c'],['../food_8h.html#a7ea3260cb39e59f340ee34b1f075044d',1,'food_control(uint8_t gpio, uint8_t estado, float top):&#160;food.c']]],
  ['food_5fopen_4',['FOOD_OPEN',['../food_8h.html#a5654bb8dcb86c88e80f01290da281199',1,'food.h']]],
  ['funcionalidades_3a_5',['Funcionalidades:',['../temperature_8c.html#autotoc_md0',1,'Funcionalidades:'],['../temperature_8h.html#autotoc_md1',1,'Funcionalidades:']]]
];
