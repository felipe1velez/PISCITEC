var searchData=
[
  ['window_5fsize_0',['WINDOW_SIZE',['../main_8h.html#ab3f68d59e815ea166f8c983bc6e85c5b',1,'main.h']]]
];
