var searchData=
[
  ['food_5fclose_0',['FOOD_CLOSE',['../food_8h.html#ac53ad709629ec112e3376934143921eb',1,'food.h']]],
  ['food_5fopen_1',['FOOD_OPEN',['../food_8h.html#a5654bb8dcb86c88e80f01290da281199',1,'food.h']]]
];
