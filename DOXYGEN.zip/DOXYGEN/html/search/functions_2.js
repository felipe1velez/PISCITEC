var searchData=
[
  ['food_5fcontrol_0',['food_control',['../food_8c.html#a6469255fc0e469bc665c30ae46210133',1,'food_control(uint8_t servo_gpio, uint8_t food_case, float top):&#160;food.c'],['../food_8h.html#a7ea3260cb39e59f340ee34b1f075044d',1,'food_control(uint8_t gpio, uint8_t estado, float top):&#160;food.c']]]
];
