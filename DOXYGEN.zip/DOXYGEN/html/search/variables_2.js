var searchData=
[
  ['servo_5fg_0',['servo_g',['../food_8c.html#aee736d391ecfef62623cbbb6d7273aa3',1,'food.c']]]
];
