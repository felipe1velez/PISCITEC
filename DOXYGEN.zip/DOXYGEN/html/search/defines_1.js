var searchData=
[
  ['close_5fms_0',['CLOSE_MS',['../food_8h.html#ad35cfbd6f415861350cb41dfe2f29fe8',1,'food.h']]],
  ['cold_5ftemperature_1',['COLD_TEMPERATURE',['../temperature_8h.html#a4135967abfea98482f7810f741b91b62',1,'temperature.h']]]
];
