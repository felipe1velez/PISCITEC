var searchData=
[
  ['angle_5fto_5fduty_0',['angle_to_duty',['../food_8c.html#a9c888f185acc7fa3e199fbe14a46cd3b',1,'angle_to_duty(float angle, float fix):&#160;food.c'],['../food_8h.html#aa41d859a0100b7dea8deb4c45cc8025f',1,'angle_to_duty(float angulo, float top):&#160;food.c']]],
  ['apagar_5fbuzzer_1',['apagar_buzzer',['../main_8c.html#ab820574e8191022f741537ac53977f73',1,'main.c']]]
];
