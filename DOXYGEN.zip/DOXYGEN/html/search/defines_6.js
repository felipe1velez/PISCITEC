var searchData=
[
  ['open_5fms_0',['OPEN_MS',['../food_8h.html#a3328416c99fd3d5165a2febccabdd3bf',1,'food.h']]]
];
