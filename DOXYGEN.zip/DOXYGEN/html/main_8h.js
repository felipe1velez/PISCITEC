var main_8h =
[
    [ "BUZZER_PIN", "main_8h.html#ab61d0981ed42df9e18211b273d22cfcd", null ],
    [ "ECHO_PIN", "main_8h.html#acea96cea4a13b6cb38e57a86788adf90", null ],
    [ "HEATER_PIN", "main_8h.html#a1a4cece415ae7d43099dae4ff8b8a31c", null ],
    [ "LED_PIN", "main_8h.html#ab4553be4db9860d940f81d7447173b2f", null ],
    [ "LED_TIMEOUT_MS", "main_8h.html#a3977fcc96a63519d2bf6ac1de094c0fe", null ],
    [ "LIGHT_PIN", "main_8h.html#a6ddfa85dd52c2aa1af587be3349cb467", null ],
    [ "LOW_FOOD_PIN", "main_8h.html#a5c1081269555278dca562a753357f27b", null ],
    [ "SERVO1_PIN", "main_8h.html#acc407398818b8e8fe8a1e314f762db21", null ],
    [ "TEMPERATURE_CHL", "main_8h.html#a3b6e64a12c09cce012091895a7bf0051", null ],
    [ "TRIG_PIN", "main_8h.html#a8eab89acd7dcb0e77e7b00d1749022a6", null ],
    [ "VIBRATION_PIN", "main_8h.html#a5b73bba3bf1b089d7f57fc0fb55c84ea", null ],
    [ "WINDOW_SIZE", "main_8h.html#ab3f68d59e815ea166f8c983bc6e85c5b", null ],
    [ "come_back_irq1", "main_8h.html#a5544f12be6e94c8bc28af9cd69755e8e", null ],
    [ "come_back_irq2", "main_8h.html#a3d14dff6fb6458d3f79bb9df2bd2db75", null ],
    [ "irq_call_back", "main_8h.html#a907f89562b499407007a097c4e45d489", null ],
    [ "moving_average", "main_8h.html#a0186ce71e843aaf61baa9ebde2dbc770", null ],
    [ "periodic_irq", "main_8h.html#afa89fbd5b103275db0857f2458e3bcef", null ],
    [ "timer_callback", "main_8h.html#af9a530b4e9359853e9435c6c048b71a1", null ],
    [ "trigger_pulse", "main_8h.html#a4bb11dc30af412aab90b891021dc9704", null ]
];