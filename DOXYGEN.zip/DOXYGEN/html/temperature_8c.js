var temperature_8c =
[
    [ "init_adc", "temperature_8c.html#abddb114b739412e90007c205013a9105", null ],
    [ "media_movil", "temperature_8c.html#a6634f5bff35f440121c23eb991ac11f5", null ],
    [ "read_temperature", "temperature_8c.html#a869e6863ef75261ca8f4a78c616ea2b4", null ],
    [ "temperature_control", "temperature_8c.html#a63e7afce846554b6d8df7308e8715440", null ],
    [ "heater_on", "temperature_8c.html#aa40b3c93893fc7491f12fe07ee85502f", null ]
];