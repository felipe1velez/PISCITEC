var main_8c =
[
    [ "apagar_buzzer", "main_8c.html#ab820574e8191022f741537ac53977f73", null ],
    [ "come_back_irq1", "main_8c.html#a5544f12be6e94c8bc28af9cd69755e8e", null ],
    [ "come_back_irq2", "main_8c.html#a3d14dff6fb6458d3f79bb9df2bd2db75", null ],
    [ "irq_call_back", "main_8c.html#a907f89562b499407007a097c4e45d489", null ],
    [ "main", "main_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "moving_average", "main_8c.html#a0186ce71e843aaf61baa9ebde2dbc770", null ],
    [ "oled_update_display", "main_8c.html#a664c949699641b5596a722605035fb20", null ],
    [ "periodic_irq", "main_8c.html#afa89fbd5b103275db0857f2458e3bcef", null ],
    [ "timer_callback", "main_8c.html#af9a530b4e9359853e9435c6c048b71a1", null ],
    [ "trigger_pulse", "main_8c.html#a4bb11dc30af412aab90b891021dc9704", null ],
    [ "oled", "main_8c.html#a03de839a9debec4f2265023b765444ad", null ]
];