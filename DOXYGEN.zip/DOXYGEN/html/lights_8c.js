var lights_8c =
[
    [ "lights_control", "lights_8c.html#a9179a7d6ad1f280369c76a9a98947901", null ],
    [ "media_movil2", "lights_8c.html#a372d65281b6b80ad5df38ef300b97497", null ],
    [ "pwm_init_basic", "lights_8c.html#aa7bc2ced61a6e62280343b17cebc80dd", null ],
    [ "read_lights", "lights_8c.html#a26a91c989ed5e5c7a8f8253cdc693cb4", null ]
];