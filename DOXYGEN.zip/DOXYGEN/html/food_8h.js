var food_8h =
[
    [ "CLOSE_MS", "food_8h.html#ad35cfbd6f415861350cb41dfe2f29fe8", null ],
    [ "FOOD_CLOSE", "food_8h.html#ac53ad709629ec112e3376934143921eb", null ],
    [ "FOOD_OPEN", "food_8h.html#a5654bb8dcb86c88e80f01290da281199", null ],
    [ "OPEN_MS", "food_8h.html#a3328416c99fd3d5165a2febccabdd3bf", null ],
    [ "angle_to_duty", "food_8h.html#aa41d859a0100b7dea8deb4c45cc8025f", null ],
    [ "food_control", "food_8h.html#a7ea3260cb39e59f340ee34b1f075044d", null ],
    [ "servo_pwm_init", "food_8h.html#a274545a3bf8210779fde1fbcd3e01d20", null ]
];