var temperature_8h =
[
    [ "COLD_TEMPERATURE", "temperature_8h.html#a4135967abfea98482f7810f741b91b62", null ],
    [ "HOT_TEMPERATURE", "temperature_8h.html#abb52224614027056054a716f883a174a", null ],
    [ "TEMP_WINDOW_SIZE", "temperature_8h.html#ac411e77a9c1eeccba64434d161155810", null ],
    [ "init_adc", "temperature_8h.html#abddb114b739412e90007c205013a9105", null ],
    [ "media_movil", "temperature_8h.html#a6634f5bff35f440121c23eb991ac11f5", null ],
    [ "read_temperature", "temperature_8h.html#a869e6863ef75261ca8f4a78c616ea2b4", null ],
    [ "temperature_control", "temperature_8h.html#a63e7afce846554b6d8df7308e8715440", null ]
];