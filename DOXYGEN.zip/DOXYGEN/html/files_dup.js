var files_dup =
[
    [ "food.c", "food_8c.html", "food_8c" ],
    [ "food.h", "food_8h.html", "food_8h" ],
    [ "lights.c", "lights_8c.html", "lights_8c" ],
    [ "lights.h", "lights_8h.html", "lights_8h" ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "main.h", "main_8h.html", "main_8h" ],
    [ "temperature.c", "temperature_8c.html", "temperature_8c" ],
    [ "temperature.h", "temperature_8h.html", "temperature_8h" ]
];