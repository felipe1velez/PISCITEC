var food_8c =
[
    [ "angle_to_duty", "food_8c.html#a9c888f185acc7fa3e199fbe14a46cd3b", null ],
    [ "food_control", "food_8c.html#a6469255fc0e469bc665c30ae46210133", null ],
    [ "servo_pwm_init", "food_8c.html#af04ff1078dae8fb32829f3405a6f1259", null ],
    [ "servo_g", "food_8c.html#aee736d391ecfef62623cbbb6d7273aa3", null ],
    [ "top_g", "food_8c.html#aefad3bdfc148a00c6ba05c652b74010f", null ]
];